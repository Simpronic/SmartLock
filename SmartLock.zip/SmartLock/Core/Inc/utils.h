/*
 * utils.h
 *
 *  Created on: Jul 9, 2023
 *      Author: marcodifiandra
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_

enum MotorState{
	start,
	ninety_degree
};

enum Fasi{
	setting,
	f_menu,
	doorActive
};

enum JoystickPosition{
	zeroPosition,
	up,
	down,
	notValid
};

#endif /* INC_UTILS_H_ */
